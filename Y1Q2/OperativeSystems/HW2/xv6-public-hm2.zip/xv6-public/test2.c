#include "types.h"
#include "user.h"
#include "syscall.h"

int main(){
	int *p = 0;

	printf(1,"%d\n", *p);
	exit();
}
