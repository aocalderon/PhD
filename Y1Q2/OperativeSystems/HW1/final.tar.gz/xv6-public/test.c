#include "types.h"
#include "user.h"
#include "syscall.h"

int main (int argc, char *argv[]){
	int n;
	n = atoi(argv[1]);
	int t;
	t = atoi(argv[2]);
	int s;
	
	s = secs();
	work(n, t);
	printf(1,"iterations=%d\n", n);
	printf(1,"tickets=%d\n", t);
	printf(1,"secs=%d\n", secs() - s);
	exit();
}
