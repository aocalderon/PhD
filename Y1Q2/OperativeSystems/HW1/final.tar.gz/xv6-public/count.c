#include "types.h"
#include "user.h"
#include "syscall.h"

int main(){
  printf(1,"my system call %d \n", counter());
  exit();
  return 0;
}
