#include "types.h"
#include "user.h"
#include "syscall.h"

int main (int argc, char *argv[]){
	int n;
	int t;
	int s;
	int i;
	
	n = atoi(argv[1]);
	if(n == 0) n = 10;
	t = atoi(argv[2]);
	if(t == 0) t = 7;
	settickets(t);
	i = 0;
	s = secs();
	while(i < n){
		if(secs() == s){
			top();
			i = i + 1;
			s = s + 5;
		}
	}
	exit();
}
