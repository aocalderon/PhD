#include "types.h"
#include "user.h"
#include "x86.h"

struct lock {
  uint locked;       // Is the lock held?
};
struct lock a_lock;

int n = 5;

struct anderson_lock {
  uint *slots;       // Is the lock held?
  uint next_slot;
};

int thread_create2(void *(*start_routine)(void*), void *arg){
	int size = 4096;
	char *stack = malloc(2 * size);
	
	int tid = clone(stack, size);
	if(tid == -1){
		(*start_routine)(arg);
		free(stack);
		exit();
	} 
	return tid;
}

void
init_lock(struct lock *lk)
{
  lk->locked = 0;
}

void
init_anderson_lock(struct anderson_lock *lk, uint nthreads)
{
  init_lock(&a_lock);
  lk->slots = malloc(nthreads*sizeof(uint));
  int i;
  for(i = 0; i < nthreads; i++) lk->slots[i] = 0;
  lk->slots[0] = 1;
  lk->next_slot = 0;
}

void
acquire_lock(struct lock *lk)
{
  //if(holding(lk)) panic("acquire");
  // The xchg is atomic.
  // It also serializes, so that reads after acquire are not
  // reordered before it. 
  while(xchg(&lk->locked, 1) != 0);
}

// Release the lock.
void
release_lock(struct lock *lk)
{
  //if(!holding(lk)) panic("release");

  // The xchg serializes, so that reads before release are 
  // not reordered after it.  The 1996 PentiumPro manual (Volume 3,
  // 7.2) says reads can be carried out speculatively and in
  // any order, which implies we need to serialize here.
  // But the 2007 Intel 64 Architecture Memory Ordering White
  // Paper says that Intel 64 and IA-32 will not move a load
  // after a store. So lock->locked = 0 would work here.
  // The xchg being asm volatile ensures gcc emits it after
  // the above assignments (and after the critical section).
  xchg(&lk->locked, 0);
}

uint
acquire_anderson_lock(struct anderson_lock *lk)
{
  uint myplace;
  xchg(&myplace, lk->next_slot);
  xchg(&lk->next_slot, lk->next_slot + 1);
  myplace = myplace % n;
  while(lk->slots[myplace] == 0) /*printf(1,"[%d]", myplace)*/;
  return myplace;
}



void
release_anderson_lock(struct anderson_lock *lk, uint myplace)
{
  //if(!holding(lk)) panic("release");

  // The xchg serializes, so that reads before release are 
  // not reordered after it.  The 1996 PentiumPro manual (Volume 3,
  // 7.2) says reads can be carried out speculatively and in
  // any order, which implies we need to serialize here.
  // But the 2007 Intel 64 Architecture Memory Ordering White
  // Paper says that Intel 64 and IA-32 will not move a load
  // after a store. So lock->locked = 0 would work here.
  // The xchg being asm volatile ensures gcc emits it after
  // the above assignments (and after the critical section).
  //printf(1, "RELEASE %d ", myplace);
  //int i;
  //printf(1,"%d %d\n", myplace, lk->next_slot);
  //for(i = 0; i < n; i++) printf(1,"%d ", lk->slots[i]);
  //printf(1,"\n");  
  xchg(&lk->slots[myplace % n], 0);
  xchg(&lk->slots[(myplace + 1) % n], 1);
}

