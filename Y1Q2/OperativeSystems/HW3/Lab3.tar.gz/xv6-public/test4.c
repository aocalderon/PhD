#include "types.h"
#include "user.h"
#include "thread.h"

int x = 1;
struct anderson_lock our_lock;

void *my_function(void *arg){
	int i;
	int j = (int)arg;
	for(i = 0; i < 32; i++){
		acquire_anderson_lock(&our_lock, j);
		printf(1,"I am thread %d, Let's see x = %d\n", j, x);
		x = x + 1;
		release_anderson_lock(&our_lock, j);
		//sleep(100);
	}
	return 0;
}

int main(int argc, char *argv[]){
	init_anderson_lock(&our_lock, 32);

	int i;
	for(i = 0; i < 32; i++){
		thread_create2(*my_function, (int*)i);
	}
	for(i = 0; i < 32; i++){
		wait();
	}
	
	exit();
}
