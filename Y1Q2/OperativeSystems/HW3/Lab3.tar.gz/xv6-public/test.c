#include "types.h"
#include "user.h"
#include "thread.h"

char *ustack;
int x = 0;

int main(int argc, char *argv[]){
	ustack = malloc(4096);
	
	printf(1, "User stack at %p and contains %s\n", ustack);
	int pid = fork();
	//int pid = clone(ustack, 4096);
	//int pid = thread_create();
	printf(1, "PID at clone %d\n", pid);
	
	if(pid > 0){
		for(;;){
			printf(1, "I am the parent, Let's see, x = %d\n", x);
			sleep(100);
		}
	} else if(pid == 0){
		for(;;){
			x++;
			sleep(300);
			printf(1, "I am the child, I've just incremented x...\n");
		}
	}
	exit();
}
