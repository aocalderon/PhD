#include "types.h"
#include "user.h"
#include "thread.h"

int x = 0;

void *my_function(void *arg){
	x += (int)arg;
	printf(1,"Let's see x = %d\n", x);
	
	return 0;
}

int main(int argc, char *argv[]){

	exit();
}


