#include "types.h"
#include "user.h"
#include "thread.h"

int x = 0;

void *my_function(void *arg){
	x += (int)arg;
	printf(1,"Let's see x = %d\n", x);
	
	return 0;
}

int main(int argc, char *argv[]){
	int pid = thread_create();
	printf(1, "PID at clone %d\n", pid);
	
	if(pid > 0){
		for(;;){
			printf(1, "I am the parent, I increment x by 5\n");
			(*my_function)((int*) 5);
			sleep(500);
		}
	} else if(pid == 0){
		for(;;){
			printf(1, "I am the child, I increment x by 1\n");
			(*my_function)((int*) 1);
			sleep(200);
		}
	}
	exit();
}


