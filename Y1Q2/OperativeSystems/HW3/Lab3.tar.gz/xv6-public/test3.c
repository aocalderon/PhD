#include "types.h"
#include "user.h"
#include "thread.h"

int x = 1;
struct lock our_lock;

void *my_function(void *arg){
	int i;
	//int j = (int)arg;
	for(i = 0; i < 20; i++){
		//printf(1,"I am thread %d, ", j);
		//acquire_lock(&our_lock);
		x++;
		printf(1,"Let's see x = %d\n", x);
		//release_lock(&our_lock);
		//sleep(200);
	}
	//printf(1,"Let's see x = %d\n", x);
	return 0;
}

int main(int argc, char *argv[]){
	//int x = 10;
	init_lock(&our_lock);

	//printf(1,"The address of x is %d and its value is %d\n", &x, x);
	int i;
	for(i = 0; i < 20; i++){
		thread_create2(*my_function, (int*)i);
	}
	for(i = 0; i < 20; i++){
		wait();
	}
	
	exit();
}
