#include "types.h"
#include "user.h"
#include "x86.h"

int n;

struct lock {
  uint locked;
};

int thread_create2(void *(*start_routine)(void*), void *arg){
	int size = 4096;
	char *stack = malloc(2 * size);
	
	int tid = clone(stack, size);
	if(tid == -1){
		(*start_routine)(arg);
		free(stack);
		exit();
	} 
	return tid;
}

void init_lock(struct lock *lk) {
  lk->locked = 0;
}

void acquire_lock(struct lock *lk){
  while(xchg(&lk->locked, 1) != 0);
}

void release_lock(struct lock *lk){
  xchg(&lk->locked, 0);
}

struct anderson_lock {
  uint *slots;
  uint next_slot;
};

void init_anderson_lock(struct anderson_lock *lk, uint nthreads){
  lk->slots = malloc(nthreads*sizeof(uint));
  int i;
  for(i = 0; i < nthreads; i++) lk->slots[i] = 0;
  lk->slots[0] = 1;
  lk->next_slot = 0;
}

uint acquire_anderson_lock(struct anderson_lock *lk){
  uint myplace;
  xchg(&myplace, lk->next_slot);
  xchg(&lk->next_slot, lk->next_slot + 1);
  myplace = myplace % n;
  while(lk->slots[myplace] == 0);
  return myplace;
}

void release_anderson_lock(struct anderson_lock *lk, uint myplace){
  xchg(&lk->slots[myplace % n], 0);
  xchg(&lk->slots[(myplace + 1) % n], 1);
}
