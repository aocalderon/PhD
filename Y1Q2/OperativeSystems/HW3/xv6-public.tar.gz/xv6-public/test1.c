#include "thread.h"

int x = 1;
int nthreads = 4;
struct lock our_lock;

void *my_function(void *arg){
	int i;
	int j = (int)arg;
	for(i = 0; i < nthreads; i++){
		acquire_lock(&our_lock);
			printf(1,"I am thread %d, Let's see x = %d.\n", j, x);
			x = x + 1;
		release_lock(&our_lock);
		sleep(10);
	}
	return 0;
}

int main(int argc, char *argv[]){
	init_lock(&our_lock);

	int i;
	for(i = 0; i < nthreads; i++){
		thread_create2(*my_function, (int*)i);
	}
	for(i = 0; i < nthreads; i++){
		wait();
	}
	
	exit();
}
