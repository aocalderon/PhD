#include "thread.h"

int x = 1;
int stop;
struct anderson_lock our_lock;

void *my_function(void *arg){
	int j = (int)arg;
	int k;
	for(;;){
		k = acquire_anderson_lock(&our_lock);
			if(x > stop){ 
				release_anderson_lock(&our_lock, k);
				break;
			}
			printf(1,"It is turn %d, I am thread %d and I have the frisbee...\n", x, j);
			x = x + 1;
		release_anderson_lock(&our_lock, k);
	}
	return 0;
}

int main(int argc, char *argv[]){
	n = atoi(argv[1]);
	stop = atoi(argv[2]);
	init_anderson_lock(&our_lock, n);

	int i;
	for(i = 0; i < n; i++){
		thread_create2(*my_function, (int*)i);
	}
	for(i = 0; i < n; i++){
		wait();
	}
	
	exit();
}
