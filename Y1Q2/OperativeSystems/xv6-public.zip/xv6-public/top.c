#include "types.h"
#include "user.h"
#include "syscall.h"

int main (int argc, char *argv[]){
	int t;
	//int s;
	int i;
	
	t = atoi(argv[1]);
	settickets(t);
	i = 0;
	//s = secs();
	while(i < 10){
		top();
		i = i + 1;
	}
	exit();
}
