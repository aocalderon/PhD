#include "types.h"
#include "user.h"
#include "syscall.h"

int main (int argc, char *argv[]){
	int n;
	n = atoi(argv[1]);

	int i;
	for(i = 0; i < n; i++){
		if(i % 100000000 == 0){
			numtickets();
		}
	}
	exit();
}
